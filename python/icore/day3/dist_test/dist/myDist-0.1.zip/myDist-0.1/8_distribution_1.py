def dist1():
    print("distribution 1")
