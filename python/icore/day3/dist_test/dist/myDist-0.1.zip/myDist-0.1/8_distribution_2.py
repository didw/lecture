def dist2():
    print("distribution 2")
