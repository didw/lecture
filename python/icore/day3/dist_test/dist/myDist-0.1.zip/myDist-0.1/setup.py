from distutils.core import setup

setup(name = "myDist",
      version = "0.1",
      description = "test distribution",
      py_modules=["8_distribution_1", "8_distribution_2"]      
)
