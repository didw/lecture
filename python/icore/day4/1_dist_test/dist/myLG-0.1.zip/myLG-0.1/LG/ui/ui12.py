def ui12Fn():
    print("ui12 fn called")