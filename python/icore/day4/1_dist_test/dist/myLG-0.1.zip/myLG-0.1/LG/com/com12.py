def com12Fn():
    print("com12 fn called")