__all__ = ['com11', 'com12']
print('com init')