from distutils.core import setup

setup(name = "myWIN",
      version = "0.1",
      description = "test distribution",
      my_modules=["win1", "win2"]      
)

#### 1 >>> python setup.py sdist
#### 2 >>> pip install myDist-0.1.zip
