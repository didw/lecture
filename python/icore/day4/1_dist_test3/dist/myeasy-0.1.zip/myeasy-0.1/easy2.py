def easy2Fn():
    print("easy2 fn call")