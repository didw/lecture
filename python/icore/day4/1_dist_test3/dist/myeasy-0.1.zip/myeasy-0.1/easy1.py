def easy1Fn():
    print("easy1fn call")